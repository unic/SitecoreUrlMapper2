ace.define("ace/snippets/powershell", ["require", "exports", "module"], function(e, t, n) {
    t.snippetText = "Get-Item",
        t.scope = "powershell";
})